PyECC
=====

Pure Python implementation of an elliptic curve cryptosystem based on FIPS 186-3