class SecurityViolationException(Exception):
    pass
